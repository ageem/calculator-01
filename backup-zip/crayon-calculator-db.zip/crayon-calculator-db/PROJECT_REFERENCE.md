# IT Legend Calculator – Project Reference

Authoritative snapshot of what this project is, how it works, and the exact files/endpoints to touch. Use this when starting a new context or picking work back up.

## Quick actions (common changes)

- Change dashboard password
  1. Edit `get_submissions.php` and `delete_submission.php` → set the same `$dashboard_password` string in both files.
  2. Users will be prompted on first visit; on a 401 the dashboard re‑prompts automatically. To force a re‑prompt, run in DevTools: `sessionStorage.removeItem('dashboard_password')` and reload.

- Change email recipients (submission notification)
  1. Open `submit.php`.
  2. Update the recipient in the PHPMailer section (look for `$mail->addAddress('mikeagee@gmail.com');`).
  3. Optionally add more recipients via additional `$mail->addAddress('name@example.com');` lines.
  4. If your host requires authenticated SMTP, configure `$mail->Host`, `$mail->SMTPAuth`, `$mail->Username`, `$mail->Password`, `$mail->SMTPSecure`, `$mail->Port`.

- Swap UI versions
  - Defaults are already new (`index.html`, `dashboard.html`). Legacy kept as `index-v1.html`, `dashboard-v1.html`.

- Reset the stored dashboard password in browser
  - DevTools Console: `sessionStorage.removeItem('dashboard_password')` → reload page.

## What it is

An interactive, single‑page “IT services value calculator” that:
- Guides users through 3 steps (Challenges → Environment → Results)
- Computes Estimated Annual Impact across recommended services
- Captures leads (contact info + selections + computed impact)
- Sends an email notification and stores a CSV backup
- Provides an admin dashboard to view/export/delete submissions

Two generations of UI exist side‑by‑side:
- Default UI (new): `index.html` (calculator), `dashboard.html` (dashboard, dark theme)
- Legacy UI: `index-v1.html`, `dashboard-v1.html` (kept for reference)

Backend is plain PHP for broad shared‑hosting compatibility. Data is saved to `data/submissions.csv`.

## Quick start (hosting)

1) Upload all files to your web host (PHP 7+ recommended).
2) Ensure PHP can write to `data/`:
   - Create `data/` if missing; permissions commonly 755 (dir) and 666 for the file once created.
3) Visit `index.html`, submit a test entry.
4) Open `dashboard.html` (enter password when prompted) to verify the new row appears; test delete and export.

## File map (must‑know)

- `index.html`
  - New calculator UI (dark theme) with embedded JS.
  - Posts JSON to `submit.php`.
  - Optional `analytics.js` loaded (safe if missing).
  - Uses jsPDF (CDN) for optional PDF generation.

- `submit.php`
  - Validates/sanitizes payload; writes to `data/submissions.csv`.
  - Sends an email (PHPMailer via localhost:25, no auth). Falls back to `mail()`.
  - Recipient currently: `mikeagee@gmail.com`.
  - In local dev (HTTP_HOST contains localhost/127.0.0.1), email send is simulated; CSV still writes.

- `dashboard.html`
  - New dashboard UI (dark theme). On load it:
    - Prompts once per session for dashboard password (stored in `sessionStorage`).
    - Calls `get_submissions.php?password=…` to list rows.
    - Calls `delete_submission.php` with JSON `{ timestamp, email, index, password }` to delete a row.
    - Offers CSV export of current in‑memory data.
  - If `401 Unauthorized` occurs, it clears the stored password, re‑prompts, and retries.

- `dashboard-v1.html`
  - Legacy dashboard (kept for reference) with same endpoints.

- `index-v1.html`
  - Legacy calculator (kept for reference).

- `get_submissions.php` (GET)
  - Returns JSON `{ success, submissions[], total_count, last_updated }`.
  - Requires `password` query parameter when a password is configured.

- `delete_submission.php` (POST JSON)
  - Deletes a matching CSV row (by `Timestamp` + `Email`). Creates a backup file before rewrite.
  - Requires `password` in JSON body when a password is configured.

- `PHPMailer-master/PHPMailer-master/`
  - Vendored PHPMailer library used by `submit.php`.

- `data/submissions.csv`
  - Auto‑created; canonical backup of all submissions.

## Current configuration

- Dashboard password (required): `Cr@yon-IT-L3g3nd!`
  - Set in: `get_submissions.php` and `delete_submission.php`.
  - Frontend stores it in `sessionStorage` under key `dashboard_password`.

- Email routing (submit.php)
  - Sends to: `mikeagee@gmail.com` (change later if needed).
  - SMTP: `Host=localhost`, `Port=25`, no auth. Falls back to PHP `mail()`.
  - Local testing: email simulated; use the dashboard/CSV to verify.

## Frontend data model (payload to submit.php)

```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@company.com",
  "company": "Acme Corp",
  "phone": "+1 (555) 123-4567",
  "painPoints": [1, 3, 7],
  "technologies": ["Azure", "M365", "IBM"],
  "hasEA": true,
  "seats": 1000,
  "estimatedImpact": 1234567,
  "recommendedServices": ["Cloud Optimization", "EA Managed Service", "AWS CloudSmart"],
  "timestamp": "2025-01-01T12:34:56.000Z"
}
```

## CSV schema (data/submissions.csv)

Columns (in order):
1. `Timestamp` (server time, e.g., `YYYY-MM-DD HH:MM:SS`)
2. `First Name`
3. `Last Name`
4. `Email`
5. `Company`
6. `Phone`
7. `Organization Size` (formatted text, e.g., `1,000 users`)
8. `Pain Points` (semicolon‑separated names)
9. `Technologies` (comma‑separated names)
10. `Has EA` (Yes/No)
11. `Estimated Impact` (e.g., `$1,234,567`)
12. `Recommended Services` (semicolon‑separated)
13. `IP Address`

## Calculation logic (high level)

- User selects challenges → mapped to service keys (e.g., `co` Cloud Optimization, `ea` EA Managed Service, etc.).
- Services filtered for compatibility with selected technologies and EA status.
- CSP Care Pack bundling removes overlapping services when CSP conditions are met.
- Each service’s impact is computed from seats * reference values (e.g., license spend, productivity uplift). Totals are sorted to rank services.
- Results screen shows total impact + per‑service impact breakdown and citations.

## Security

- Input sanitization in `submit.php` (`sanitizeInput`) covers arrays and strings.
- Dashboard endpoints require a password (`Cr@yon-IT-L3g3nd!`).
- Recommend protecting `data/` via `.htaccess` on Apache hosts (deny direct download). See `deployment_instructions.md`.

## Troubleshooting & gotchas

- Dashboard 401 after password change:
  - `dashboard.html` clears the stored password and re‑prompts on 401. You can also run `sessionStorage.removeItem('dashboard_password')` in DevTools and reload.

- Email not sending in production:
  - Host may block `localhost:25` or require authenticated SMTP. Adjust PHPMailer settings in `submit.php` accordingly.

- Local testing shows success but no email:
  - Expected; local branch simulates email delivery. Check `data/submissions.csv` instead.

## Common operations

- Change dashboard password:
  - Update the password string in both `get_submissions.php` and `delete_submission.php`.

- Change email recipient(s):
  - Edit recipients in `submit.php` (currently `mikeagee@gmail.com`).

- Deploy update in small steps:
  - Make the change, verify `index.html` submit → CSV write → dashboard shows row.
  - Keep legacy files (`index-v1.html`, `dashboard-v1.html`) intact for reference until satisfied.

## Status overview

- New calculator: wired to `submit.php` and fully functional.
- New dashboard: functional (list, export, delete) with dark theme and password prompt.
- Password currently set site‑wide for dashboard APIs.
- PHPMailer present and integrated; fallback `mail()` in place.

## Useful URLs (relative to deployment root)

- Calculator (new): `index.html`
- Dashboard (new): `dashboard.html`
- APIs:
  - `get_submissions.php?password=<PASSWORD>` (GET)
  - `delete_submission.php` (POST JSON: `{ timestamp, email, index, password }`)
  - Submission endpoint: `submit.php` (POST JSON)

## Notes for future improvements (optional)

- Switch to authenticated SMTP if host requires it (TLS/587 credentials).
- Persist dashboard auth via cookie + server‑side verification instead of query/body secret.
- Move calculations to a shared module or backend if needed.
- Replace CSV with a database for concurrency/reporting at scale.


