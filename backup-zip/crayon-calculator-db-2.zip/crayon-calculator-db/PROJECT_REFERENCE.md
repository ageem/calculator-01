# IT Legend Calculator – Project Reference

Authoritative snapshot of what this project is, how it works, and the exact files/endpoints to touch. Use this when starting a new context or picking work back up.

## Quick actions (common changes)

- Change dashboard password
  1. Edit `get_submissions.php` and `delete_submission.php` → set the same `$dashboard_password` string in both files.
  2. Users will be prompted on first visit; on a 401 the dashboard re‑prompts automatically. To force a re‑prompt, run in DevTools: `sessionStorage.removeItem('dashboard_password')` and reload.

- Change email recipients (submission notification)
  1. Open `submit.php`.
  2. Update the recipient in the PHPMailer section (look for `$mail->addAddress('mikeagee@gmail.com');`).
  3. Optionally add more recipients via additional `$mail->addAddress('name@example.com');` lines.
  4. If your host requires authenticated SMTP, configure `$mail->Host`, `$mail->SMTPAuth`, `$mail->Username`, `$mail->Password`, `$mail->SMTPSecure`, `$mail->Port`.

- Add or update styles (CSS)
  1. Edit `assets/css/index.css` (all calculator/dashboard styles are centralized there).
  2. If you add new CSS files, place them under `assets/css/` and link from `index.html` as needed.

- Add or update scripts (JS)
  1. Edit `assets/js/index.js` (all calculator logic has been externalized here).
  2. All UI functions used by inline attributes are exported on `window` (e.g., `window.calculateImpact`, `window.handleLeadSubmit`, `window.generateAndDownloadPDF`).
  3. If you split JS into multiple files, place them under `assets/js/` and include them in `index.html` before `index.js` when order matters.

- The application uses a single, modern UI implementation

- Reset the stored dashboard password in browser
  - DevTools Console: `sessionStorage.removeItem('dashboard_password')` → reload page.

## What it is

An interactive, single‑page “IT services value calculator” that:
- Guides users through 3 steps (Challenges → Environment → Results)
- Computes Estimated Annual Impact across recommended services
- Captures leads (contact info + selections + computed impact)
- Sends an email notification and stores a CSV backup
- Provides an admin dashboard to view/export/delete submissions

The application provides a modern, single-page experience with:
- `index.html` (calculator) - Interactive IT services value calculator
- `dashboard.html` (dashboard) - Admin dashboard with dark theme

Backend is plain PHP for broad shared‑hosting compatibility. Data is saved to `data/submissions.csv`.

## Quick start (hosting)

1) Upload all files to your web host (PHP 7+ recommended).
2) Ensure PHP can write to `data/`:
   - Create `data/` if missing; permissions commonly 755 (dir) and 666 for the file once created.
3) Visit `index.html`, submit a test entry.
4) Open `dashboard.html` (enter password when prompted) to verify the new row appears; test delete and export.

## File map (must‑know)

- `index.html`
  - New calculator UI (dark theme).
  - Loads external CSS/JS: `assets/css/index.css`, `assets/js/index.js`.
  - Posts JSON to `submit.php`.
  - Optional `analytics.js` loaded (safe if missing).
  - Uses jsPDF (CDN) for optional PDF generation.

- `submit.php`
  - Validates/sanitizes payload; writes to `data/submissions.csv`.
  - Sends an email (PHPMailer via localhost:25, no auth). Falls back to `mail()`.
  - Recipient currently: `mikeagee@gmail.com`.
  - In local dev (HTTP_HOST contains localhost/127.0.0.1), email send is simulated; CSV still writes.

- `dashboard.html`
  - New dashboard UI (dark theme). On load it:
    - Prompts once per session for dashboard password (stored in `sessionStorage`).
    - Calls `get_submissions.php?password=…` to list rows.
    - Calls `delete_submission.php` with JSON `{ timestamp, email, index, password }` to delete a row.
    - Offers CSV export of current in‑memory data.
  - If `401 Unauthorized` occurs, it clears the stored password, re‑prompts, and retries.



- `get_submissions.php` (GET)
  - Returns JSON `{ success, submissions[], total_count, last_updated }`.
  - Requires `password` query parameter when a password is configured.

- `delete_submission.php` (POST JSON)
  - Deletes a matching CSV row (by `Timestamp` + `Email`). Creates a backup file before rewrite.
  - Requires `password` in JSON body when a password is configured.

- `PHPMailer-master/PHPMailer-master/`
  - Vendored PHPMailer library used by `submit.php`.

- `data/submissions.csv`
  - Auto‑created; canonical backup of all submissions.

- `assets/css/index.css`
  - Centralized styles for the calculator UI (migrated from inline `<style>` in `index.html`).

- `assets/js/index.js`
  - Centralized calculator logic (migrated from inline `<script>` in `index.html`).
  - Exposes UI functions on `window` for inline attributes (e.g., `scrollToDetailsSection`, `handleLeadSubmit`, `calculateImpact`, `generateAndDownloadPDF`, `scheduleCall`).
  - Contains data maps (`serviceData`, `painPointMapping`, etc.), calculations, event wiring (DOMContentLoaded), and UI rendering.

## Current configuration

- Dashboard password (required): `Cr@yon-IT-L3g3nd!`
  - Set in: `get_submissions.php` and `delete_submission.php`.
  - Frontend stores it in `sessionStorage` under key `dashboard_password`.

- Email routing (submit.php)
  - Sends to: `mikeagee@gmail.com` (change later if needed).
  - SMTP: `Host=localhost`, `Port=25`, no auth. Falls back to PHP `mail()`.
  - Local testing: email simulated; use the dashboard/CSV to verify.

- Frontend assets
  - CSS: `assets/css/index.css` (single entry point, linked from `index.html`).
  - JS: `assets/js/index.js` (single entry point, linked from `index.html` after jsPDF/analytics).
  - All previous inline CSS/JS has been removed from `index.html`.

## Frontend data model (payload to submit.php)

```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@company.com",
  "company": "Acme Corp",
  "phone": "+1 (555) 123-4567",
  "painPoints": [1, 3, 7],
  "technologies": ["Azure", "M365", "IBM"],
  "hasEA": true,
  "seats": 1000,
  "estimatedImpact": 1234567,
  "recommendedServices": ["Cloud Optimization", "EA Managed Service", "AWS CloudSmart"],
  "timestamp": "2025-01-01T12:34:56.000Z"
}
```

## CSV schema (data/submissions.csv)

Columns (in order):
1. `Timestamp` (server time, e.g., `YYYY-MM-DD HH:MM:SS`)
2. `First Name`
3. `Last Name`
4. `Email`
5. `Company`
6. `Phone`
7. `Organization Size` (formatted text, e.g., `1,000 users`)
8. `Pain Points` (semicolon‑separated names)
9. `Technologies` (comma‑separated names)
10. `Has EA` (Yes/No)
11. `Estimated Impact` (e.g., `$1,234,567`)
12. `Recommended Services` (semicolon‑separated)
13. `IP Address`

## Calculation logic (high level)

- User selects challenges → mapped to service keys (e.g., `co` Cloud Optimization, `ea` EA Managed Service, etc.).
- Services filtered for compatibility with selected technologies and EA status.
- CSP Care Pack bundling removes overlapping services when CSP conditions are met.
- Each service’s impact is computed from seats * reference values (e.g., license spend, productivity uplift). Totals are sorted to rank services.
- Results screen shows total impact + per‑service impact breakdown and citations.

## Security

- Input sanitization in `submit.php` (`sanitizeInput`) covers arrays and strings.
- Dashboard endpoints require a password (`Cr@yon-IT-L3g3nd!`).
- Recommend protecting `data/` via `.htaccess` on Apache hosts (deny direct download). See `deployment_instructions.md`.
- JS global exposure: functions used by inline attributes are intentionally exported on `window`. If converting away from inline attributes, remove those `window.*` exports.

## Troubleshooting & gotchas

- Dashboard 401 after password change:
  - `dashboard.html` clears the stored password and re‑prompts on 401. You can also run `sessionStorage.removeItem('dashboard_password')` in DevTools and reload.

- Email not sending in production:
  - Host may block `localhost:25` or require authenticated SMTP. Adjust PHPMailer settings in `submit.php` accordingly.

- Local testing shows success but no email:
  - Expected; local branch simulates email delivery. Check `data/submissions.csv` instead.

- JS not running / function not found:
  - Ensure `assets/js/index.js` is included after `analytics.js` and jsPDF in `index.html`.
  - Verify required functions are exported on `window` (e.g., `window.calculateImpact`).
  - If you split JS into multiple files, include them before `index.js` when dependencies are needed.

## Common operations

- Change dashboard password:
  - Update the password string in both `get_submissions.php` and `delete_submission.php`.

- Change email recipient(s):
  - Edit recipients in `submit.php` (currently `mikeagee@gmail.com`).

- Deploy update in small steps:
  - Make the change, verify `index.html` submit → CSV write → dashboard shows row.
  - Test thoroughly before deploying to production.

- Add new UI behavior:
  - Implement in `assets/js/index.js`. Add event listeners in the DOMContentLoaded block.
  - If referenced from HTML attributes, export the function on `window`.

## Status overview

- Calculator: wired to `submit.php` and fully functional.
- Dashboard: functional (list, export, delete) with dark theme and password prompt.
- Password currently set site‑wide for dashboard APIs.
- PHPMailer present and integrated; fallback `mail()` in place.
- CSS/JS fully externalized: `index.html` contains no inline `<style>` or functional `<script>` blocks.

## Useful URLs (relative to deployment root)

- Calculator: `index.html`
- Dashboard: `dashboard.html` (also accessible at `/dashboard` via URL rewriting)
- APIs:
  - `get_submissions.php?password=<PASSWORD>` (GET)
  - `delete_submission.php` (POST JSON: `{ timestamp, email, index, password }`)
  - Submission endpoint: `submit.php` (POST JSON)

## Notes for future improvements (optional)

- Switch to authenticated SMTP if host requires it (TLS/587 credentials).
- Persist dashboard auth via cookie + server‑side verification instead of query/body secret.
- Move calculations to a shared module or backend if needed.
- Replace CSV with a database for concurrency/reporting at scale.

## Assistant operational guidelines

- See `assistant-guidelines.md` for batching rules to avoid large edits and Cursor freezes.
- Key points:
  - Work in small, verified batches (≤ ~150 changed lines or ≤ 3 files per batch)
  - Prefer targeted edits (`search_replace`) over whole-file rewrites
  - Parallelize reads/searches; serialize writes/edits
  - Re-read files before subsequent patches if prior edits occurred
  - After each batch: test, check console/network URLs, and proceed

This project expects careful, incremental changes to keep deployments predictable.

## URL Rewriting and Dashboard Access

The dashboard, originally `dashboard.html`, is now accessible via a clean URL: `/dashboard`. This is achieved through URL rewriting rules configured in the `.htaccess` file located in the project's root directory (`/calc-test-02/`).

**Key points:**
- Accessing `https://mikeagee.com/calc-test-02/dashboard` (with or without a trailing slash) will serve `dashboard.html`.
- API calls within `dashboard.html` (e.g., `get_submissions.php`, `delete_submission.php`) now use **absolute paths** (e.g., `/calc-test-02/get_submissions.php`) to ensure correct routing regardless of the dashboard's URL structure. This resolves issues with relative paths when the dashboard is accessed via a rewritten URL.
- The `.htaccess` file also includes rules for protecting the `data` directory and `.csv` files from direct web access.

**URL Rewriting Rules:**
- `/dashboard` → serves `dashboard.html`
- `/dashboard/` → serves `dashboard.html` 
- `/index` → serves `index.html` (without .html extension)

## Project Structure Tree

```
crayon-calculator-db/
├── assets/
│   ├── css/
│   │   └── index.css
│   └── js/
│       └── index.js
├── data/
│   └── submissions.csv
├── images/
│   └── Crayon-Logo-RGB-Negative.png
├── PHPMailer-master/
│   └── PHPMailer-master/
│       ├── src/
│       │   ├── PHPMailer.php
│       │   ├── SMTP.php
│       │   └── Exception.php
│       └── language/ (multiple language files)
├── .htaccess
├── assistant-guidelines.md
├── dashboard.html (main dashboard)
├── delete_submission.php
├── get_submissions.php
├── index.html (main calculator)
├── PROJECT_REFERENCE.md
├── README.md
└── submit.php
```

**Key Files for Dashboard Functionality:**
- `dashboard.html` - Main dashboard interface (accessible at `/dashboard`)
- `.htaccess` - URL rewriting rules for clean URLs
- `get_submissions.php` - API endpoint for fetching submissions
- `delete_submission.php` - API endpoint for deleting submissions
- `data/submissions.csv` - Data storage (protected from direct web access)


