# Assistant Work Guidelines (Cursor‑optimized) 🌟

## TL;DR for Cursor

- Prefer small, targeted edits. Cap each batch at ≈150 changed lines or ≤3 files.
- Discover in parallel; write/modify sequentially. Re‑read a file before a second patch.
- Use `search_replace`/surgical diffs; never reformat unrelated code.
- After every batch: lint/check, quick test, verify Network/Console, then proceed.
- For 2+ step changes, create a short TODO and keep only one item in_progress.
- If unsure, pause and inspect/ask—don’t guess. Roll back the last small change when needed.

## Operational mindset (short)

- Optimize for small, correct batches; finish one step before starting the next.
- Communicate the next step briefly, then do exactly that.
- Pause when uncertain; inspect context rather than guessing.
- Roll back the last change on regressions; avoid compounding issues.
- Favor clarity and maintainability over speed.

## Cursor Batching Guardrails (Avoid Freezes & Oversized Edits)

Use these practical limits to stay fast and reliable in Cursor:

- Small, safe edits
  - Prefer targeted `search_replace`/single-file edits over large rewrites
  - Avoid touching unrelated lines; never reformat whole files
  - Keep each edit batch under ~150 changed lines or 3 files, whichever is smaller

- Work in batches
  - Break multi-file changes into sequential, verifiable steps
  - After each step: save, run a quick test or reload, then proceed
  - If a change cascades, pause and re-scan context before the next batch

- Plan before editing
  - Create a short TODO list for 2+ step tasks (track progress, one item in_progress)
  - State what you’ll do next; then do exactly that edit
  - Stop when done with that item—even if more improvements are obvious

- Tooling discipline
  - Re-read a file before a second patch if earlier edits may have shifted lines
  - Prefer exact-match `search_replace` for surgical changes to large files
  - Use parallel read/search calls for discovery; serialize writes/edits

- Error control
  - If something fails: revert the last small change rather than pushing forward
  - Limit yourself to at most 2 quick follow-up fixes per file before re-checking context
  - When unsure, pause and ask/inspect rather than guessing

- Performance & UX
  - Avoid long-running background tasks without clear need
  - Don’t add console noise in production code; keep temporary logs minimal and remove when done

- Verification checklist per batch
  - No linter/syntax errors introduced
  - CSS/JS paths correct (prefer absolute paths when URL rewriting is involved)
  - For URL rules: verify both canonical and trailing-slash variants
  - For fetches: confirm Network tab shows expected absolute URL

These guardrails keep edits small, testable, and resilient—reducing Cursor stalls and preventing large, risky diffs.